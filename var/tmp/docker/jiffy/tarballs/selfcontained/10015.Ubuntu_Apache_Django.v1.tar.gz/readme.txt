#Created by jiffy automatically.

group_name "Ubuntu/Apache/Django"
group_ref_hash "328e9e77e07c4de249b816589991b711"
