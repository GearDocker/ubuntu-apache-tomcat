name "wrapper"

description "The wrapper cookbook self contained config S1Q939K6UXXNAT4X"

run_list "role[apache_django]", "recipe[apt::default]", "recipe[vim::default]", "recipe[build-essential::default]", "recipe[git::default]", "recipe[apache2::mod_wsgi]", "recipe[python::default]", "recipe[django::apache]"

