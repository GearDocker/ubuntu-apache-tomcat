name "wrapper"

description "The wrapper cookbook self contained config Base.1,fe4a23ed431003480e51f3e5bd215f45.5bdebf400d89f017e1a2e0a6c5caacee"

run_list "recipe[custom::default]"

