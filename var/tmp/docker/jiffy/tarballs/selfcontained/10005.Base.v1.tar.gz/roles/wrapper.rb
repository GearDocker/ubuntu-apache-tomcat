name "wrapper"

description "The wrapper cookbook self contained config Base.1,925eab34ae9c5c8b05cb8477871d02ce.ef0a2dd26f89ef7b79bc742bbb6f7271"

run_list "recipe[custom::default]"

