#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr
#version: 1
#file_check_hash: 8d0fab19094ae7125bfc09838af84935
#file_ref_hash: 6d98a7df05ff418536997a3d9b5b48a6
directory '/usr' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc
#version: 1
#file_check_hash: 32d539ef88f469af099793f9e69fe807
#file_ref_hash: 32470adb61f626f9e04c17d837500de9
directory '/etc' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/root
#version: 1
#file_check_hash: 800d62b68b241e910210642883690cdd
#file_ref_hash: cf887b110dafc89d93adbdf9fd4f7f3e
directory '/root' do
    owner 'root'
    group 'root'
    mode '0700'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local
#version: 1
#file_check_hash: 84eafbe907b424d4e787372ae91da66d
#file_ref_hash: e4133c17b07f9ca7d23fc5e0c1e4d033
directory '/usr/local' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local/scripts
#version: 1
#file_check_hash: ce8ddc5067681d44d9a159fca65ebcf2
#file_ref_hash: 694f1ff93f2eaedcd5515dca77a10476
directory '/usr/local/scripts' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh
#version: 1
#file_check_hash: 2d072354e76d5f6d05fb478bdefa0399
#file_ref_hash: ffb8c051be2ade721d52ff7d6bf0e99e
directory '/etc/ssh' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local/scripts/sys_stats2syslog.sh
#version: 1
#file_check_hash: b36ed20e621e3a1255807f3aa7e32945
#file_ref_hash: dcf070e58a54ce62617fb89027582207
#md5sum_file: c316929a07be70a609c199acd2afb7eb
#filename: sys_stats2syslog.sh 
cookbook_file '/usr/local/scripts/sys_stats2syslog.sh' do
    source 'c316929a07be70a609c199acd2afb7eb'
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/ssh_config
#version: 1
#file_check_hash: be07b8ad79f9669a8f83f0655fd95b1b
#file_ref_hash: dc837d4083969884bdf44fb1ea37eedc
#md5sum_file: 51b2c2b65171959d376dbd59741960cb
#filename: ssh_config 
cookbook_file '/etc/ssh/ssh_config' do
    source '51b2c2b65171959d376dbd59741960cb'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/sshd_config
#version: 1
#file_check_hash: 3151b3673c45588d00b283cd010d7584
#file_ref_hash: e98665868f32af79b77cd3574d82efca
#md5sum_file: ac56c80abf47864597ff0581f9ebfe67
#filename: sshd_config 
cookbook_file '/etc/ssh/sshd_config' do
    source 'ac56c80abf47864597ff0581f9ebfe67'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/moduli
#version: 1
#file_check_hash: eb784cc9b1e3476a27dee25ba4d6571f
#file_ref_hash: b88f56291a6ff302f5b8049801592d82
#md5sum_file: b1c007bf229d5d1707a2aebe9732f13c
#filename: moduli 
cookbook_file '/etc/ssh/moduli' do
    source 'b1c007bf229d5d1707a2aebe9732f13c'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/root/.bashrc
#version: 1
#file_check_hash: 7c3b2752406f41194225ed03b4183a7a
#file_ref_hash: 72d4e0304c89fbe2ef000d404a6df112
#md5sum_file: 45b6200d17c510bcb93ea64ca2aa8ada
#filename: .bashrc 
cookbook_file '/root/.bashrc' do
    source '45b6200d17c510bcb93ea64ca2aa8ada'
    owner 'root'
    group 'root'
    mode '0644'
end

