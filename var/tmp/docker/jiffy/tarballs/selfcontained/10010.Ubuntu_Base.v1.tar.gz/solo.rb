#Created by jiffy automatically.

file_cache_path "/var/chef-solo"
cookbook_path ["/var/chef-solo/cookbooks"]
role_path "/var/chef-solo/roles"
