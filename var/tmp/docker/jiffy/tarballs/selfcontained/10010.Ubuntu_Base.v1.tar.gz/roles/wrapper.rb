name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/Base.1,9a6113c304dbca4e551ae168d012fc81.d472eb1180a3b6a24c8ccb1fd2815500"

run_list "recipe[custom::default]"

