name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/Base.1,aab37719555b4098c0e223992b30d120.b6dc8348e60094abd654a0e450da8fcc"

run_list "recipe[custom::default]"

