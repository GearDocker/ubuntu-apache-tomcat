name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/Base.1,f1fae6ada4d2997c422079a990d86c9a.d5f955b1f98e6404af24996cb09c87aa"

run_list "recipe[custom::default]"

