#Created by jiffy automatically.

group_name "Ubuntu/Apache/Tomcat"
group_ref_hash "7f61cca9d7af8c1ba33cce0f797415bc"
