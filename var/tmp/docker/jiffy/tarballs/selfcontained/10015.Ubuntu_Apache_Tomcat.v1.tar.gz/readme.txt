#Created by jiffy automatically.

group_name "Ubuntu/Apache/Tomcat"
group_ref_hash "3ca45408377d80efa9649b1a9c3b0846"
