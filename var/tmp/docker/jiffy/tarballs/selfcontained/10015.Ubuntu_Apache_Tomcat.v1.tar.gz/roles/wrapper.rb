name "wrapper"

description "The wrapper cookbook self contained config 31SSU8K26VGSWV57"

run_list "role[tomcat_attr]", "recipe[wtomcat::apt_update]", "recipe[java::default]", "recipe[tomcat::default]"

