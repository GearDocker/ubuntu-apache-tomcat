name "wrapper"

description "The wrapper cookbook self contained config H6EWDUL64B6M8N8G"

run_list "role[tomcat_attr]", "recipe[wtomcat::apt_update]", "recipe[java::default]", "recipe[tomcat::default]"

