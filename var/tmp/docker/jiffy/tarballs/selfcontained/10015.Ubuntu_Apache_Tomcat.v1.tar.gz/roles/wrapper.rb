name "wrapper"

description "The wrapper cookbook self contained config 6FTADR1TKTZ6WT06"

run_list "role[tomcat_attr]", "recipe[wtomcat::apt_update]", "recipe[java::default]", "recipe[tomcat::default]"

