name "wrapper"

description "The wrapper cookbook self contained config OTLR2AX3BEWEEDI4"

run_list "role[tomcat_attr]", "recipe[wtomcat::apt_update]", "recipe[java::default]", "recipe[tomcat::default]"

