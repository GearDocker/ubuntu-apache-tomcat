execute 'zypper_refresh' do
  command 'zypper refresh'
  user 'root'
end
